//
//  ZHBaseRequest.m
//  customAutoLayout
//
//  Created by sobeycloud on 2018/1/18.
//  Copyright © 2018年 sobeycloud. All rights reserved.
//

#import "ZHBaseRequest.h"
#import "ZHRequestManager.h"

@implementation ZHBaseRequest

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.requestBaseURL = @"";
        self.requestURL = @"";
        self.requestTimeoutInterval = 60;
        self.requestMethod = ZHRequestMethodGet;
        //Base Param
        self.requestParameters = [self query];
        self.requestSerializerType = ZHRequestSerializerTypeForm;
        self.responseSerializerType = ZHResponseSerializerTypeJSON;
        self.useCookies = YES;
        self.constructionBodyBlock = nil;
        
    }
    return self;
}

#pragma mark private
- (NSDictionary *)query
{
    //共有参数
    self.requestParameters = [NSMutableDictionary dictionary];

    [self.requestParameters setObject:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]?[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]:nil forKey:@"version"];
    //需要验证用户是否登录存取token值
    [self.requestParameters setObject:@"iOS" forKey:@"platform"];

    [self.requestParameters setObject:[self idfvString] forKey:@"device_token"];
    
    return self.requestParameters;
}
- (NSString *)idfvString
{
    if([[UIDevice currentDevice] respondsToSelector:@selector(identifierForVendor)]) {
        return [[UIDevice currentDevice].identifierForVendor UUIDString];
    }
    return @"";
}


#pragma publick method

- (NSTimeInterval)requestTimeoutInterval
{
    return _requestTimeoutInterval;
}

- (void)requestWillStartTag {
    
    if (self.requestStartBlock) {
        self.requestStartBlock(self);
    }
    
    if ([self.delegate respondsToSelector:@selector(requestWillStart:)]) {
        [self.delegate requestWillStart:self];
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:ZHRequestWillStartNotification object:self];
    });
    
    [self requestWillStart];
}

- (BOOL)isLoading
{
    
    return self.task.state != NSURLSessionTaskStateCompleted;
    
}

- (void)start {
    [self requestWillStartTag];
    [[ZHRequestManager shareManager] startRequest:self];
}

- (void)startWithRequestSuccessBlock:(void(^)(ZHBaseRequest *request))success  resultClass:(Class)resultClass failureBlock:(void(^)(ZHBaseRequest *request))failure {
    self.responseClass = resultClass;
    [self setRequestSuccessBlock:success failureBlock:failure];
    [self start];
    
}

- (void)setRequestSuccessBlock:(void(^)(ZHBaseRequest *request))success failureBlock:(void(^)(ZHBaseRequest *request))failure {
    self.successCompletionBlock = success;
    self.failureCompletionBlock = failure;
}

- (void)stop {
    [[ZHRequestManager shareManager] cancelRequest:self];
}


#pragma mark --

- (void)requestWillStart {
    
}

- (void)requestCompleteSuccess {
    
}

- (void)requestCompleteFailure {
    
}

- (void)methodPath
{
}

@end

NSString * const ZHRequestWillStartNotification = @"com.ZH.request.start";
NSString * const ZHRequestDidFinishNotification = @"com.ZH.request.finish";


