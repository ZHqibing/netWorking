//
//  ZHBaseResult.m
//  customAutoLayout
//
//  Created by sobeycloud on 2018/1/18.
//  Copyright © 2018年 sobeycloud. All rights reserved.
//

#import "ZHBaseResult.h"

@implementation ZHBaseResult

- (void)setStatus:(id)status {
    
    _status = status;
    
    if ([_status objectForKey:@""]) {
        
        self.success = YES;
    } else {
        
        self.success = NO;
    }
    
    
}

@end
