//
//  ZHBaseRequest.h
//  customAutoLayout
//
//  Created by sobeycloud on 2018/1/18.
//  Copyright © 2018年 sobeycloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"

/**
 *  HTTP request method
 */
typedef NS_ENUM(NSInteger, ZHRequestMethod) {
    ZHRequestMethodGet = 0,
    ZHRequestMethodPost,
    ZHRequestMethodPut,
    ZHRequestMethodDelete
};

/**
 *  request serializer type
 */
typedef NS_ENUM(NSInteger, ZHRequestSerializerType) {
    ZHRequestSerializerTypeForm = 0,
    ZHRequestSerializerTypeJSON
};

/**
 *  response serializer type
 */
typedef NS_ENUM(NSInteger, ZHResponseSerializerType) {
    ZHResponseSerializerTypeHTTP = 0,
    ZHResponseSerializerTypeJSON
};

@class ZHBaseRequest;
typedef void(^ZHRequestCompletionBlock)(__kindof ZHBaseRequest *request);

//请求协议方法
@protocol ZHRequestDelegate <NSObject>

@optional
- (void)requestWillStart:(ZHBaseRequest *)request;
- (void)requestDidSuccess:(ZHBaseRequest *)request;
- (void)requestDidFailure:(ZHBaseRequest *)request;

@end

//请求基类
@interface ZHBaseRequest : NSObject


@property (nonatomic, strong) NSURLSessionDataTask *task;

#pragma mark -- 返回数据信息

@property (nonatomic, copy) void(^requestStartBlock)(ZHBaseRequest *);

@property (nonatomic, copy) void (^uploadProgress)(NSProgress *progress);

@property (nonatomic, copy) ZHRequestCompletionBlock successCompletionBlock;

@property (nonatomic, copy) ZHRequestCompletionBlock failureCompletionBlock;
//解析后的数据
@property (nonatomic, strong) id responseObject;
// response json object，is raw data
@property (nonatomic, strong) id jsonResponseObject;
// response statusCode number
@property (nonatomic, readonly) NSInteger responseStatusCode;
// the response class
@property (nonatomic, strong) Class responseClass;
// error info
@property (nonatomic, strong) NSError *error;


//协议
@property (nonatomic, weak) id <ZHRequestDelegate> delegate;


#pragma mark -- custom properties

/**
 requestBaseURL 和 requestURL 之间存在的 ‘/’很关键
 如 requestBaseURL 为：http://v.juhe.cn/ 那么 requestUrl 要为：toutiao/index
 或者 requestBaseURL为： http://v.juhe.cn 那么 requestURL 则为：/toutiao/index
 */
// default is ''
@property (nonatomic, copy) NSString *requestBaseURL;
// default is ``
@property (nonatomic, copy) NSString *requestURL;
// default is 60
@property (nonatomic, assign) NSTimeInterval requestTimeoutInterval;
// default is `ZHRequestMethodGET`
@property (nonatomic, assign) ZHRequestMethod requestMethod;
// default is save appKey、 version、 deviceId ,if login will save token.
@property (nonatomic, strong) id requestParameters;
// default is `ZHRequestSerializerTypeJSON`
@property (nonatomic, assign) ZHRequestSerializerType requestSerializerType;
// default is `ZHResponseSerializerTypeJSON`
@property (nonatomic, assign) ZHResponseSerializerType responseSerializerType;
// default is YES
@property (nonatomic, assign) BOOL useCookies;
// POST upload request such as images, default nil
@property (nonatomic, copy) void (^constructionBodyBlock)(id<AFMultipartFormData>formData);


// 开始请求
- (void)start;

- (void)startWithRequestSuccessBlock:(void(^)(ZHBaseRequest *request))success resultClass:(Class)resultClass failureBlock:(void(^)(ZHBaseRequest *request))failure;


#pragma mark -- method

//request url
- (void)methodPath;

// toggle when requst start
- (void)requestWillStart;

// toggle when request success
- (void)requestCompleteSuccess;

// toggle when request failure
- (void)requestCompleteFailure;

@end

/**
 *  通知
 */
FOUNDATION_EXPORT NSString * const ZHRequestWillStartNotification;
FOUNDATION_EXPORT NSString * const ZHRequestDidFinishNotification;
