//
//  ZHRequestTool.h
//  customAutoLayout
//
//  Created by sobeycloud on 2018/1/18.
//  Copyright © 2018年 sobeycloud. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZHRequestTool : NSObject

//判断URL 是否正确（正则表达式判断）
+ (BOOL)validateUrl:(NSString *)url;

// 对字符串 MD5 加密
+ (NSString *)md5String:(NSString *)string;

@end
