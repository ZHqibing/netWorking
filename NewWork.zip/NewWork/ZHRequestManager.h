//
//  ZHRequestManager.h
//  customAutoLayout
//
//  Created by sobeycloud on 2018/1/18.
//  Copyright © 2018年 sobeycloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZHBaseRequest.h"

@interface ZHRequestManager : NSObject

+ (instancetype)shareManager;

- (void)startRequest:(ZHBaseRequest *)request;
- (void)cancelRequest:(ZHBaseRequest *)request;
- (void)cancelAllRequests;

// start monitor network status
- (void)startNetworkStateMonitoring;

@end
