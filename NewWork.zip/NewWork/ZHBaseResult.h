//
//  ZHBaseResult.h
//  customAutoLayout
//
//  Created by sobeycloud on 2018/1/18.
//  Copyright © 2018年 sobeycloud. All rights reserved.
//

#import <Foundation/Foundation.h>

// 响应基类
@interface ZHBaseResult : NSObject

/**
 *  返回成功标志
 */
@property (nonatomic, assign) BOOL success;

/**
 * 返回状态数据，通过返回的状态判断请求成功与否
 */
@property (nonatomic, strong) id status;


// 其他返回数据信息 酌情添加


@end
