//
//  ZHRequestManager.m
//  customAutoLayout
//
//  Created by sobeycloud on 2018/1/18.
//  Copyright © 2018年 sobeycloud. All rights reserved.
//

#import "ZHRequestManager.h"


#define ZH_HTTP_COOKIE_KEY @"ZHHTTPCookieKey"

@interface ZHRequestManager()

@property (nonatomic, strong) AFHTTPSessionManager *sessionManager;
@property (nonatomic, strong) AFURLSessionManager *urlSessionManager;
@property (nonatomic, strong) NSMutableDictionary *requests;

@end

@implementation ZHRequestManager

+ (instancetype)shareManager {
    
    static ZHRequestManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[ZHRequestManager alloc] init];
    });
    return instance;
}

- (instancetype)init {
    
    if (self = [super init]) {
        
        self.sessionManager = [AFHTTPSessionManager manager];
        self.urlSessionManager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
        self.requests = [NSMutableDictionary dictionary];
        
    }
    
    return self;
}


#pragma mark - cookies
- (void)saveCookies {
    NSHTTPCookieStorage *cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    NSArray *cookies = [cookieStorage cookies];
    if (cookies.count > 0) {
        NSData *cookieData = [NSKeyedArchiver archivedDataWithRootObject:cookies];
        
        [[NSUserDefaults standardUserDefaults] setObject:cookieData forKey:ZH_HTTP_COOKIE_KEY];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

- (void)loadCookies {
    id cookieData = [[NSUserDefaults standardUserDefaults] objectForKey:ZH_HTTP_COOKIE_KEY];
    if (!cookieData) {
        return;
    }
    NSArray *cookies = [NSKeyedUnarchiver unarchiveObjectWithData:cookieData];
    if ([cookies isKindOfClass:[NSArray class]] && cookies.count > 0) {
        NSHTTPCookieStorage *cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
        for (NSHTTPCookie *cookie in cookies) {
            [cookieStorage setCookie:cookie];
        }
    }
}


#pragma mark - 请求结束处理
- (void)requestDidFinishTag:(ZHBaseRequest *)request {
    
    if (request.error) {
        if (request.failureCompletionBlock) {
            request.failureCompletionBlock(request);
        }
        //请求失败代理执行
        if ([request.delegate respondsToSelector:@selector(requestDidFailure:)]) {
            [request.delegate requestDidFailure:request];
        }
        
        [request requestCompleteFailure];
        
    } else {
        if (request.successCompletionBlock) {
            request.successCompletionBlock(request);
        }
        //请求成功代理执行
        if ([request.delegate respondsToSelector:@selector(requestDidSuccess:)]) {
            [request.delegate requestDidSuccess:request];
        }
        
        [request requestCompleteSuccess];
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:ZHRequestDidFinishNotification object:request];
    });
}

- (void)handleReponseResult:(NSURLSessionDataTask *)task response:(id)responseObject error:(NSError *)error{
    
    NSString *key = [self taskHashKey:task];
    
    ZHBaseRequest *request = self.requests[key];
    
    // 未转化的json字符串
    request.jsonResponseObject = responseObject;
    // 需要我们自动转换(采用YYModel或者mj)
//    request.responseObject = [request.responseClass modelWithJSON:responseObject];
//    request.responseObject = [request.responseClass mj_objectWithKeyValues:responseObject];
    
    request.error = error;
    
    if (error) {
        NSLog(@"错误日志：URL:%@/n描述：%@",request.requestURL,error.localizedDescription);
    }
    
    // 使用cookie时需要保存cookie
    if (request.useCookies) {
        [self saveCookies];
    }
    
    // 发送结束tag
    [self requestDidFinishTag:request];
    
    // 请求成功后移除此次请求
    [self removeRequest:task];
   
    
}


- (NSString *)taskHashKey:(NSURLSessionDataTask *)task
{
    return [NSString stringWithFormat:@"%lu", (unsigned long)[task hash]];
}

// 管理`request`的生命周期, 防止多线程处理同一key
- (void)addRequest:(ZHBaseRequest *)request {
    
    if (request.task) {
        NSString *key = [self taskHashKey:request.task];
        @synchronized(self) {
            [self.requests setValue:request forKey:key];
        }
    }
}

- (void)removeRequest:(NSURLSessionDataTask *)task {
    
    NSString *key = [self taskHashKey:task];
    @synchronized(self) {   //线程保护
        [self.requests removeObjectForKey:key];
    }
}


#pragma mark --
- (NSString *)configRequestURL:(ZHBaseRequest *)request {
    
    // 初始化url
    [request methodPath];

    if ([request.requestURL hasPrefix:@"http"]) {
        return request.requestURL;
    }

    if ([request.requestBaseURL hasPrefix:@"http"]) {
        return [NSString stringWithFormat:@"%@%@", request.requestBaseURL, request.requestURL];
    } else {
        NSLog(@"未配置好请求地址 %@ requestURL: %@", request.requestBaseURL, request.requestURL);
        return @"";
    }
    
    return @"";
}


#pragma mark

- (void)startRequest:(ZHBaseRequest *)request {
    
    NSString *url = [self configRequestURL:request];
    
    //请求数据格式设置
    ZHRequestSerializerType requestSerializerType = request.requestSerializerType;
   switch (requestSerializerType) {
        case ZHRequestSerializerTypeForm:
            self.sessionManager.requestSerializer = [AFHTTPRequestSerializer serializer];
            break;
        case ZHRequestSerializerTypeJSON:
            self.sessionManager.requestSerializer = [AFJSONRequestSerializer serializer];
        default:
            break;
    }
    
    //响应数据格式
    ZHResponseSerializerType responseSerializerType = request.responseSerializerType;
    switch (responseSerializerType) {
        case ZHResponseSerializerTypeJSON:
            self.sessionManager.responseSerializer = [AFJSONResponseSerializer serializer];
            break;
        case ZHResponseSerializerTypeHTTP:
            self.sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
            break;
        default:
            break;
    }
    
    self.sessionManager.requestSerializer.timeoutInterval = request.requestTimeoutInterval;
    self.sessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html",@"application/json",@"text/plain",@"text/json",@"multipart/form-data", nil];
    
    //请求参数的处理
    id params = request.requestParameters;
    
    //条件参数等参数
//    [params setObject:@"someType" forKey:@"someType"];
    
    //请求头参数等
//     [self.sessionManager.requestSerializer setValue:@"signature" forHTTPHeaderField:@"signature"];
    
    
    //防止参数错误
    if (request.requestSerializerType == ZHRequestSerializerTypeJSON) {
        if (![NSJSONSerialization isValidJSONObject:params] && params) {
            NSLog(@"error in JSON parameters：%@", params);
            return;
        }
    }
    NSLog(@"请求参数:%@", params);
    NSLog(@"请求接口:%@",[self configRequestURL:request]);
    
    // 处理请求
    ZHRequestMethod requestMethod = request.requestMethod;
    NSURLSessionDataTask *task = nil;
    switch (requestMethod) {
        case ZHRequestMethodGet:
        {
            task = [self.sessionManager GET:url parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                [self handleReponseResult:task response:responseObject error:nil];
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                [self handleReponseResult:task response:nil error:error];
            }];
            
        }
            break;
            
        case ZHRequestMethodPost:
        {
            if ([request constructionBodyBlock]) {
                // 图片上传
                task = [self.sessionManager POST:url parameters:params constructingBodyWithBlock:[request constructionBodyBlock] progress:^(NSProgress * _Nonnull uploadProgress) {
                    
                    if (request.uploadProgress) {
                        request.uploadProgress(uploadProgress);
                        
                    }
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    [self handleReponseResult:task response:responseObject error:nil];
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    [self handleReponseResult:task response:nil error:error];
                }];
                
                
                
            } else {
                task = [self.sessionManager POST:url parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    [self handleReponseResult:task response:responseObject error:nil];
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    [self handleReponseResult:task response:nil error:error];
                }];
            }
        }
            break;
            
        case ZHRequestMethodPut:
        {
            task = [self.sessionManager PUT:url parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                [self handleReponseResult:task response:responseObject error:nil];
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                [self handleReponseResult:task response:nil error:error];
            }];
        }
            break;
            
        case ZHRequestMethodDelete:
        {
            task = [self.sessionManager DELETE:url parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                [self handleReponseResult:task response:responseObject error:nil];
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                [self handleReponseResult:task response:nil error:error];
            }];
        }
            break;
        default:
            break;
    }
    
    request.task = task;
    [self addRequest:request];
}

- (void)cancelRequest:(ZHBaseRequest *)request {
    [request.task cancel];
    [self removeRequest:request.task];
}

- (void)cancelAllRequests {
    for (NSString *key in self.requests.allKeys) {
        ZHBaseRequest *request = self.requests[key];
        [self cancelRequest:request];
    }
    
}


- (void)startNetworkStateMonitoring {
    
    
}


@end


